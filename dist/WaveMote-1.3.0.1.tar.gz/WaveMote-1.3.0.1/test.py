import WaveMote as wm

wm.mouse()